package pageObjects.Modules;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.hamcrest.Factory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;
import com.qa.utils.ExplicitWaiting;
import com.qa.utils.Verification;

public class SignUp_01_PageObject {
	
	Verification  vr=new Verification();
	
	/* x-path for sign-up button*/
	@FindBy(xpath="//a[text()='Sign up']")
	private WebElement sign_up;
	
	/* x-path for email-id*/
	@FindBy(xpath="//input[@id='signup-email']")
	private WebElement email_id;
	
	/* x-path for password*/
	@FindBy(xpath="//input[@id='signup-password']")
	private WebElement password;
	
	/*x-path for start free trail button*/
	@FindBy(xpath="//button[@id='CyberSafety_Trial_Lead_Button']")
	private WebElement start_free_trail;
	
	/*x-path for Signin button*/ 
	 @FindBy(xpath="//button[@id='sign-in-button']")
	 private WebElement signin_button;
	 
	 /*xpath for cyber safety logo*/
	 @FindBy(xpath="//span[@id='header-zeguro-logo']")
	 private WebElement cyber_safety_logo;
	 
	 /* xapth for cyber safety page*/
	 @FindBy(xpath="//div[text()='Welcome to Cyber Safety.']")
	 private WebElement cyber_safety_page;
	 
	 
	 /*xpath for profile logo*/
	 @FindBy(xpath="//span[@class='sc-hjsNop iRqgLp fas fa-user-circle']")
	 private WebElement profile_logo;
	 
	 /*xpath for emailid text */
	 @FindBy(xpath="//div[@class='sc-gGWvLE dBkbLx']/span")
	 private WebElement emaild_text;
	 
	 /*xpath for onbording button*/
	 @FindBy(xpath="//button[@id='onboarding-continue']")
	 private WebElement onboarding_button;
	 
	 /*xpath for company name textbox*/
	 @FindBy(xpath="//input[@id='onboarding-company-name']")
	 private WebElement company_name;
	 
	 /* xpath for sign in */
	 @FindBy(xpath="//input[@id='signInInput']")
	 private WebElement sign_in_email;
	 
	 
	 /*xpath for primary indusry dropdowm*/
	 @FindBy(xpath="//button[@id='onboarding-primary-industry']")
	 private WebElement primary_indusry;

	 /*xpath for primary team member dropdowm*/
	 @FindBy(xpath="//button[@id='onboarding-number-of-team-members']")
	 private WebElement team_member;


	 /*xpath for primary next button*/
	 @FindBy(xpath="//button[text()='Next']")
	 private WebElement next1;
	 
	 @FindBy(xpath="//input[@id='signInPassword']")
	 private WebElement sign_in_password;
	 
	 
	 /*x-path for invited user*/
	 @FindBy(xpath="//input[@id='onboarding-invite-user']")
	 private WebElement invited_user;
	 
	 /*x-path for Done*/
	 @FindBy(xpath="//button[@id='CyberSafety_Trial_OrgInfo_Button_page_3']")
	 private WebElement done;
	 
	 /*xpath for Got it*/
	 @FindBy(xpath="//button[text()='Got It']")
	 private WebElement gotit_button;
	 
	 
	 /*xpath for Security Policy card*/
	 @FindBy(xpath="//div[text()=' SECURITY POLICIES']")
	 private WebElement security_policy_card;
	 
	 
	 /*xpath for training Policy card*/
	 @FindBy(xpath="//div[text()=' TRAINING']")
	 private WebElement training_card;
	 

	 /*xpath for monitoring card*/
	 @FindBy(xpath="//div[text()=' MONITORING']")
	 private WebElement monitoring_card;
	 	 

	 /*xpath for marketplace card*/
	 @FindBy(xpath="//div[text()=' MARKETPLACE']")
	 private WebElement marketplace_card;
	 

	 /*xpath for dashboard*/
	 @FindBy(xpath="//div[text()='Dashboard']")
	 private WebElement dashboard;
	 
	 /*xpath for SecurityPolicy*/
	 @FindBy(xpath="//div[text()='Security Policies']")
	 private WebElement security_policies;
	 
	 /*xpath for trainig*/
	 @FindBy(xpath="//div[text()='Training']")
	 private WebElement training;
	 
	 
	 /*xpath for monitoring*/
	 @FindBy(xpath="//div[text()='Monitoring']")
	 private WebElement monitoring;
	 
	/*xpath for insurance*/
	 @FindBy(xpath="//div[text()='Insurance']")
	 private WebElement insurance;
	 	 
	 
	 public WebElement getMarketplace_card() {
		return marketplace_card;
	}
	public void setMarketplace_card(WebElement marketplace_card) {
		this.marketplace_card = marketplace_card;
	}
	public WebElement getDashboard() {
		return dashboard;
	}
	public void setDashboard(WebElement dashboard) {
		this.dashboard = dashboard;
	}
	public WebElement getSecurity_policies() {
		return security_policies;
	}
	public void setSecurity_policies(WebElement security_policies) {
		this.security_policies = security_policies;
	}
	public WebElement getTraining() {
		return training;
	}
	public void setTraining(WebElement training) {
		this.training = training;
	}
	public WebElement getMonitoring() {
		return monitoring;
	}
	public void setMonitoring(WebElement monitoring) {
		this.monitoring = monitoring;
	}
	public WebElement getInsurance() {
		return insurance;
	}
	public void setInsurance(WebElement insurance) {
		this.insurance = insurance;
	}
	public WebElement getSetting() {
		return setting;
	}
	public void setSetting(WebElement setting) {
		this.setting = setting;
	}
	public WebElement getSupport() {
		return support;
	}
	public void setSupport(WebElement support) {
		this.support = support;
	}
	public WebElement getMyplan() {
		return myplan;
	}
	public void setMyplan(WebElement myplan) {
		this.myplan = myplan;
	}
	
		/*xpath for marketplace*/
	 @FindBy(xpath="//div[text()='Marketplace']")
	 private WebElement marketplace;
	 
		/*xpath for setting*/
	 @FindBy(xpath="//a[text()='Settings']")
	 private WebElement setting;
	 
	 
		/*xpath for support*/
	 @FindBy(xpath="//a[text()='Support']")
	 private WebElement support;
	 
		/*xpath for myplan*/
	 @FindBy(xpath="//a[text()='My Plan']")
	 private WebElement myplan;
	 
 	 public WebElement getSecurity_policy_card() {
		return security_policy_card;
	}
	public void setSecurity_policy_card(WebElement security_policy_card) {
		this.security_policy_card = security_policy_card;
	}
	public WebElement getTraining_card() {
		return training_card;
	}
	public void setTraining_card(WebElement training_card) {
		this.training_card = training_card;
	}
	public WebElement getMonitoring_card() {
		return monitoring_card;
	}
	public void setMonitoring_card(WebElement monitoring_card) {
		this.monitoring_card = monitoring_card;
	}
	public WebElement getMarketplace() {
		return marketplace;
	}
	public void setMarketplace(WebElement marketplace) {
		this.marketplace = marketplace;
	}
	
	 
	 
	 public WebElement getPrimary_indusry() {
		return primary_indusry;
	}
	public void setPrimary_indusry(WebElement primary_indusry) {
		this.primary_indusry = primary_indusry;
	}
	public WebElement getTeam_member() {
		return team_member;
	}
	public void setTeam_member(WebElement team_member) {
		this.team_member = team_member;
	}
	public WebElement getNext1() {
		return next1;
	}
	public void setNext1(WebElement next1) {
		this.next1 = next1;
	}
	
	 
	 public WebElement getFirst_name() {
		return first_name;
	}
	public void setFirst_name(WebElement first_name) {
		this.first_name = first_name;
	}
	public WebElement getLast_name() {
		return last_name;
	}
	public void setLast_name(WebElement last_name) {
		this.last_name = last_name;
	}
	public WebElement getJob_title() {
		return job_title;
	}
	public void setJob_title(WebElement job_title) {
		this.job_title = job_title;
	}
	/*xpath for first name*/
	 @FindBy(xpath="//input[@id='onboarding-first-name']")
	 private WebElement first_name;
	 
	 /*xpath for last  name*/
	 @FindBy(xpath="//input[@id='onboarding-last-name']")
	 private WebElement last_name;
	 
	 
	 /*xpath for qa*/
	 @FindBy(xpath="//input[@id='onboarding-job-title']")
	 private WebElement job_title;
	 
	 /*x-path for primary web address*/
	 @FindBy(xpath="//input[@id='onboarding-primary-website-address']")
	 private WebElement primary_website;
	 
	 
	 /*x-path for invited user*/
	 @FindBy(xpath="//div[text()='Invited user successfully']")
	 private WebElement invited_user_toastmessage;
	 
	 /*x-path for cyber safety module user*/
	 @FindBy(xpath="//span[text()='Welcome to Cyber Safety.']")
	 private WebElement welcome_cyber_safety;
	 
	 /*x-path for improove team member*/
	 @FindBy(xpath="//li[@class='sc-fHSyak wwDGJ'][1]")
	 private WebElement improoveTeamMemberText;
	 
	 @FindBy(xpath="//div[text()='Education']")
	 private WebElement education;
	  
	 @FindBy(xpath="//div[text()='11-20']")
	 private WebElement team_size;
	 
	 /*x-path for cybersafety logo*/
	 @FindBy(xpath="//span[@id='header-zeguro-logo']")
	 private WebElement cyber_safety_logo_oncybersafety_page;
	 
	 
	 /*x-path for manage cyber safety admin*/
	 @FindBy(xpath="//div[text()='Manage Cyber Safety Admins']")
	 private WebElement manage_cyber_tab;
	 
	 /*x-path for profile icon*/
	 @FindBy(xpath="//i[@class='sc-cHGmPC KSQWk fas fa-sort-down']")
	 private WebElement profile_icon;
	 
	 public WebElement getProfile_icon() {
		return profile_icon;
	}
	public void setProfile_icon(WebElement profile_icon) {
		this.profile_icon = profile_icon;
	}
	public WebElement getStart_trial_days() {
		return start_trial_days;
	}
	public void setStart_trial_days(WebElement start_trial_days) {
		this.start_trial_days = start_trial_days;
	}

	/*x-path for manage cyber safety admin*/
	 @FindBy(xpath="//div[text()='Your free trial ends in 30 days.']")
	 private WebElement start_trial_days;
		
	 public WebElement getPresenceof_invited_user() {
		return presenceof_invited_user;
	}
	public void setPresenceof_invited_user(WebElement presenceof_invited_user) {
		this.presenceof_invited_user = presenceof_invited_user;
	}

	/*x-path for manage setting user*/
	 @FindBy(xpath=".//div[@id='settings-user-card']/div/p[2]")
	 private WebElement presenceof_invited_user;
	 
	 public WebElement getManage_cyber_tab() {
		return manage_cyber_tab;
	}
	public void setManage_cyber_tab(WebElement manage_cyber_tab) {
		this.manage_cyber_tab = manage_cyber_tab;
	}
	public WebElement getCyber_safety_logo_oncybersafety_page() {
		return cyber_safety_logo_oncybersafety_page;
	}
	public void setCyber_safety_logo_oncybersafety_page(WebElement cyber_safety_logo_oncybersafety_page) {
		this.cyber_safety_logo_oncybersafety_page = cyber_safety_logo_oncybersafety_page;
	}

	 
	 public WebElement getWelcome_cyber_safety() {
		return welcome_cyber_safety;
	}
	public void setWelcome_cyber_safety(WebElement welcome_cyber_safety) {
		this.welcome_cyber_safety = welcome_cyber_safety;
	}
	public WebElement getImprooveTeamMemberText() {
		return improoveTeamMemberText;
	}
	public void setImprooveTeamMemberText(WebElement improoveTeamMemberText) {
		this.improoveTeamMemberText = improoveTeamMemberText;
	}
	public WebElement getScan_websitesText() {
		return scan_websitesText;
	}
	public void setScan_websitesText(WebElement scan_websitesText) {
		this.scan_websitesText = scan_websitesText;
	}
	public WebElement getContractualText() {
		return contractualText;
	}
	public void setContractualText(WebElement contractualText) {
		this.contractualText = contractualText;
	}
	/*x-path for scan websites*/
	 @FindBy(xpath="//li[@class='sc-fHSyak wwDGJ'][2]")
	 private WebElement scan_websitesText;
	 
	 /*x-path for meet contractual*/
	 @FindBy(xpath="//li[@class='sc-fHSyak wwDGJ'][3]")
	 private WebElement contractualText;
	 
	 
	 public WebElement getInvited_user_toastmessage() {
		return invited_user_toastmessage;
	}
	public void setInvited_user_toastmessage(WebElement invited_user_toastmessage) {
		this.invited_user_toastmessage = invited_user_toastmessage;
	}
	
	 public WebElement getInvited_user() {
		return invited_user;
	}
	public void setInvited_user(WebElement invited_user) {
		this.invited_user = invited_user;
	}
	public WebElement getDone() {
		return done;
	}
	public void setDone(WebElement done) {
		this.done = done;
	}
	
	 
	 
	 public WebElement getGotit_button() {
		return gotit_button;
	}
	public void setGotit_button(WebElement gotit_button) {
		this.gotit_button = gotit_button;
	}
	public WebElement getEducation() {
		return education;
	}
	public void setEducation(WebElement education) {
		this.education = education;
	}
	public WebElement getTeam_size() {
		return team_size;
	}
	public void setTeam_size(WebElement team_size) {
		this.team_size = team_size;
	}
	
	 
	 public WebElement getPrimary_website() {
		return primary_website;
	}
	public void setPrimary_website(WebElement primary_website) {
		this.primary_website = primary_website;
	}
	
	 
	 
	 
	 public WebElement getSign_in_email() {
		return sign_in_email;
	}
	public void setSign_in_email(WebElement sign_in_email) {
		this.sign_in_email = sign_in_email;
	}
	public WebElement getSign_in_password() {
		return sign_in_password;
	}
	public void setSign_in_password(WebElement sign_in_password) {
		this.sign_in_password = sign_in_password;
	}
	
	public WebElement getCompany_name() {
		return company_name;
	}
	public void setCompany_name(WebElement company_name) {
		this.company_name = company_name;
	}
	public WebElement getOnboarding_button() {
		return onboarding_button;
	}
	public void setOnboarding_button(WebElement onboarding_button) {
		this.onboarding_button = onboarding_button;
	}
	public WebElement getEmaild_text() {
		return emaild_text;
	}
	public void setEmaild_text(WebElement emaild_text) {
		this.emaild_text = emaild_text;
	}
	public WebElement getProfile_logo() {
		return profile_logo;
	}
	public void setProfile_logo(WebElement profile_logo) {
		this.profile_logo = profile_logo;
	}
	public WebElement getCyber_safety_page() {
		return cyber_safety_page;
	}
	public void setCyber_safety_page(WebElement cyber_safety_page) {
		this.cyber_safety_page = cyber_safety_page;
	}
	public WebElement getCyber_safety_logo() {
		return cyber_safety_logo;
	}
	public void setCyber_safety_logo(WebElement cyber_safety_logo) {
		this.cyber_safety_logo = cyber_safety_logo;
	}
	public WebElement getSignin_button() {
		return signin_button;
	}
	public void setSignin_button(WebElement signin_button) {
		this.signin_button = signin_button;
	}
	public WebElement getSign_up() {
		return sign_up;
	}
	public void setSign_up(WebElement sign_up) {
		this.sign_up = sign_up;
	}
	public WebElement getEmail_id() {
		return email_id;
	}
	public void setEmail_id(WebElement email_id) {
		this.email_id = email_id;
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(WebElement password) {
		this.password = password;
	}
	public WebElement getStart_free_trail() {
		return start_free_trail;
	}
	public void setStart_free_trail(WebElement start_free_trail) {
		this.start_free_trail = start_free_trail;
	}
	
	//actions
	/*click on signup button*/
	public void click_on_sugnup()
	{
	BaseMethod.mouseHoverAndClick(sign_up);

	}
	public void signin()
	{
		BaseMethod.mouseHover(signin_button);
	}
	/*enter email id*/
	public void enteremailid(String emailid) {
		email_id.sendKeys(emailid);
		
		}
	/*enter email id*/
	public void enter_company_name(String companyname) {
		company_name.sendKeys(companyname);
		
		}
	
	/*enter first name*/
	public void enter_first_name(String fname) {
	  first_name.sendKeys(fname);
		
		}
	
	/*enter first name*/
	public void enter_last_name(String lname) {
	  last_name.sendKeys(lname);
		
		}
	
	/*enter invited user name*/
	public void enter_invited_user(String iuser) {
	  invited_user.sendKeys(iuser);
		
		}
	
	
	
	/*click on next button*/
	public void enterpassword(String pass) {
	password.sendKeys(pass);
			
	}
	
	/*enter first name*/
	public void first_name(String firstname) {
		first_name.sendKeys(firstname);
		
		}
	
	/*enter first name*/
	public void last_name(String lastname) {
		last_name.sendKeys(lastname);
		
		}
	
	/*enter job title*/
	public void job_title(String jobtitle) {
		job_title.sendKeys(jobtitle);
		
		}
	public void enter_sigin_id(String sid)
	{
		BaseMethod.mouseHoverAndClick(sign_in_email);
	     sign_in_email.sendKeys(sid);
	}
	
	public void enter_sigin_pass(String sipass)
	
	{
		sign_in_password.sendKeys(sipass);
	}
	/* select primary indiry dropdown*/
	public void select_primary_industry()
	{
		BaseMethod.selectByIndex(primary_indusry,3);
	}
	/* select primary indiry dropdown*/
	public void select_team_member()
	{
		BaseMethod.selectByIndex(team_member, 1);
		}
	
	/*click on the start free trail button*/
	public void click_onStartFreeTrail() {
	BaseMethod.mouseHoverAndClick(start_free_trail);
   
    start_free_trail.click();

	}
	
	/*click on the  setting*/
	public void click_on_setting() {
	BaseMethod.mouseHoverAndClick(setting);
   
	}
	
	/*click on the  cyber safety tab*/
	public void click_on_cyber_safety_tab() {
	BaseMethod.mouseHoverAndClick(manage_cyber_tab);
   
	}

	/*click on the  cyber safety tab*/
	public void click_on_profileicon() {
	BaseMethod.mouseHoverAndClick(profile_icon);
   
	}
	/*click on next*/
	public void click_on_next1() {
	BaseMethod.mouseHoverAndClick(next1);
 

	}
	
	/*click on next*/
	public void click_on_gotit() {
	BaseMethod.mouseHoverAndClick(gotit_button);

     start_free_trail.click();

	}
	
	/*click on signin button*/
	public void click_signin_button()
	{
		BaseMethod.mouseHoverAndClick(signin_button);
		//signin_button.click();
	}
	/*click on onboarding button*/
	
	public void click_on_onboarding_button()
	{
		BaseMethod.mouseHoverAndClick(onboarding_button);
		//onboarding_button.click();
	}
	
		
	
/*click on primary industry dropdown */
	
	public void click_on_primaryindustry()
	{
		BaseMethod.mouseHoverAndClick(primary_indusry);
		//onboarding_button.click();
	}
	
	
/*click on primary done */
	
	public void click_on_done()
	{
		BaseMethod.mouseHoverAndClick(done);
		//onboarding_button.click();
	}
	
/*click on team number  dropdown */
	
	public void click_on_teammember()
	{
		BaseMethod.mouseHoverAndClick(team_member);
		//onboarding_button.click();
	}
	
	public void click_on_education()
	{
	BaseMethod.mouseHoverAndClick(education);

	}
	
	public void click_on_teamsize()
	{
	BaseMethod.mouseHoverAndClick(team_size);

	}
	/*enter primary web address*/
	public void enter_primary_webaddress(String web)
	{
		primary_website.sendKeys(web);
	}
	
	
/*click on myplan */
	
	public void click_on_myplan()
	{
		BaseMethod.mouseHoverAndClick(myplan);
		//onboarding_button.click();
	}
	
	
	
	
	//verifications
	public void verify_cyber_safety_logo()
	{
		vr.verify_image(cyber_safety_logo,"Cyber Safety logo");
	}
    /*land on Welcome to Cyber Safety page*/
	public void verify_cyber_safety_page()
	{
		vr.verify_page(cyber_safety_page,"Cyber Safety Page");
	}
	/*verfiy profile logo in upper right corener*/
	public void verify_profile_logo()
	{
		vr.verify_image(profile_logo,"Profile logo in upper right corner");
	}
	/*verfiy email id text*/
	public void verify_emailid_text()
	{
		vr.verify_text(emaild_text,"Email id in upper right corner");

	}
	/* verify invited user toast message*/
	public void verify_invited_user_toast_message()
	{
		vr.verify_text(invited_user_toastmessage, "Invited user");
	}
	
	
	/* verify welcome cyber safety page*/
	public void verify_welcome_cybersafety_module()
	{
		vr.verify_page(welcome_cyber_safety, "Welcome to Cyber Safe");
	}
	
	/* verify improoved text*/
	public void verify_improove_team_members()
	{
		vr.verify_text(improoveTeamMemberText,"Improve team members' security and compliance awareness with training.");
	}

	/* verify improoved text*/
	public void verify_scan_websites()
	{
		vr.verify_text(scan_websitesText,"Scan websites to identify and mitigate security risks.");
	}

	/* verify improoved text*/
	public void verify_contractual_text()
	{
		vr.verify_text(contractualText,"Meet contractual and regulatory obligations with customizable security policies.");
	}
	/* verify insurance */
	public void verify_insurance()
	{
		vr.verify_text(insurance, "Insurance");
	}
	/* verify security card*/
	public void verify_security_card()
	{
		vr.verify_text(security_policy_card,"Security Policy Card");
	}
	
	/* verify Training  card*/
	public void verify_training_card()
	{
		vr.verify_text(training_card,"Training Card");
	}
	
	/* verify Training  card*/
	public void verify_monitoring_card()
	{
		vr.verify_text(monitoring_card,"Monitoring Card");
	}
	
	/* verify marketplace  card*/
	public void verify_marketplace_card()
	{
		vr.verify_text(marketplace,"MarketPlace Card");
	}
	
	/* verify marketplace  card*/
	public void verify_dashboard()
	{
		vr.verify_text(dashboard,"Dashboard");
	}
	
	/* verify securitypolicy*/
	public void verify_Security_policies()
	{
		vr.verify_text(security_policies,"Security Policies");
	}
	
	/* verify marketplace*/
	public void verify_marketplace()
	{
		vr.verify_text(marketplace,"Marketplace");
	}
	
	/* verify training*/
	public void verify_training()
	{
		vr.verify_text(training,"Training");
	}
	/* verify monitoring*/
	public void verify_monitoring()
	{
		vr.verify_text(monitoring,"Monitoring");
	}
	/* verify setting*/
	public void verify_setting()
	{
		vr.verify_text(setting,"Setting");
	}
	
	/* verify myplan*/
	public void verify_myplan()
	{
		vr.verify_text(myplan,"Myplan");
	}
	
	/* verify support*/
	public void verify_support()
	{
		vr.verify_text(support,"Support");
	}
	
	/* verify cyber_safety on dashboard*/
	public void verify_cyber_safety_ondashboard()
	{
		vr.verify_image(cyber_safety_logo_oncybersafety_page, "Cyber Safety logo in the lower left corner");
	}
	
	/* verify invited user */
	public void verify_invited_user()
	{
		vr.verify_image(presenceof_invited_user, "Presence of invited user");
	}
	
	/* verify 30 days start free trailr */
	public void verify_free_trail()
	{
		vr.verify_text(start_trial_days, "Your free trial ends in 30 days");
	}
}

