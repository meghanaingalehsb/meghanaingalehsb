package com.qa.controllers;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class BaseMethod extends WebDriverFactory {
	
	/* To get the Website Name */
    public String getUrlTitle() throws Exception {
       return getWebDriver().getTitle();
    }


    /* To ScrollUp using JavaScript Executor */
    public void scrollUp() throws Exception {
        ((JavascriptExecutor) getWebDriver()).executeScript("scroll(0, -100);");
    }


    /* To ScrollDown using JavaScript Executor */
    public void scrollDown() throws Exception {
        ((JavascriptExecutor) getWebDriver()).executeScript("scroll(0, 100);");
    }


    /* To Move cursor to the Desired Location */
    public void moveCursor(int X_Position, int Y_Position) throws Exception {
        re.mouseMove(X_Position, Y_Position);
    }


    /* To Accept the Alert Dialog Message */
    public void alertAccept() throws Exception {
        al = getWebDriver().switchTo().alert();
        al.accept();
    }


    /* To Dismiss the Alert Dialog Message */
    public void alertDismiss() throws Exception {
        al = getWebDriver().switchTo().alert();
        al.dismiss();
    }


    /* To Get the Alert Messages */
    public String getAlertText() throws Exception {
        al = getWebDriver().switchTo().alert();
        String text = al.getText();
        Thread.sleep(2000);
        alertAccept();
        return text;
    }


    /* To Upload a File using JAVA AWT ROBOT */
    public void fileUpload(String FileToUpload) throws Exception {
        Thread.sleep(5000);
        StringSelection filetocopy = new StringSelection(FileToUpload);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filetocopy, null);
        Thread.sleep(1000);
        re = new Robot();
        re.keyPress(KeyEvent.VK_CONTROL);
        re.keyPress(KeyEvent.VK_V);
        re.keyRelease(KeyEvent.VK_V);
        re.keyRelease(KeyEvent.VK_CONTROL);
        re.keyPress(KeyEvent.VK_ENTER);
        re.keyRelease(KeyEvent.VK_ENTER);
    }


    /* To Perform a WebAction of Mouse Over */
    public static void mouseHover(WebElement element) {
        ac = new Actions(getWebDriver());
        ac.moveToElement(element).build().perform();
    }
    
    /* To Perform a WebAction of Mouse Over */
    public static void mouseHoverAndClick(WebElement element) {
        ac = new Actions(getWebDriver());
        ac.moveToElement(element).click().build().perform();
    }


    /* To Perform Select Option by Visible Text */
    public static void selectByVisibleText(WebElement element, String value) {
        se = new Select(element);
        se.selectByVisibleText(value);
    }


    /* To Perform Select Option by Index */
    public static void selectByIndex(WebElement element, int value) {
        se = new Select(element);
        se.selectByIndex(value);
    }


    /* To Perform Select Option by Value */
    public static void selectByValue(WebElement element, String value) {
        se = new Select(element);
        se.selectByValue(value);
    }


    /* To click a certain Web Element */
    public static void click(WebElement element) {
        element.click();
    }


    /* To click a certain Web Element using DOM/ JavaScript Executor */
    public void javaScriptExecutorClick(WebElement element) {
        ((JavascriptExecutor) getWebDriver()).executeScript("return arguments[0].click();", element);
    }


    /* To Type at the specified location */
    public static void sendKeys(WebElement element, String value) {
        element.sendKeys(value);
    }


    /* To Clear the content in the input location */
    public void clear(WebElement element) {
        element.clear();
    }


    /* To Drag and Drop from Source Locator to Destination Locator */
    public void dragAndDrop(WebElement Source, WebElement Destination) {
        ac = new Actions(getWebDriver());
        ac.dragAndDrop(Source, Destination);
    }


    /*To Drag from the given WebElement Location and Drop at the given WebElement location */
    public void dragAndDropTo(WebElement Source, int XOffset, int YOffset) throws Exception {
        ac = new Actions(getWebDriver());
        ac.dragAndDropBy(Source, XOffset, YOffset);
    }


    /*To Open a Page in New Tab */
    public void rightClick(WebElement element) {
        ac = new Actions(getWebDriver());
        ac.contextClick(element);
        ac.build().perform();
    }


    /*To Close Current Tab */
    public static void closeCurrentTab() {
        getWebDriver().close();
    }


    /*To Perform Click and Hold Action */
    public void clickAndHold(WebElement element) {
        ac = new Actions(getWebDriver());
        ac.clickAndHold(element);
        ac.build().perform();
    }


    /*To Perform Click and Hold Action */
    public static void doubleClick(WebElement element) {
        ac = new Actions(getWebDriver());
        ac.doubleClick(element);
        ac.build().perform();
    }


    /*To Switch To Frame By Index */
    public static void switchToFrameByIndex(int index) throws Exception {
        getWebDriver().switchTo().frame(index);
    }


    /*To Switch To Frame By Frame Name */
    public void switchToFrameByFrameName(String frameName) throws Exception {
        getWebDriver().switchTo().frame(frameName);
    }


    /*To Switch To Frame By Web Element */
    public void switchToFrameByWebElement(WebElement element) throws Exception {
        getWebDriver().switchTo().frame(element);
    }


    /*To Switch out of a Frame */
    public void switchOutOfFrame() throws Exception {
        getWebDriver().switchTo().defaultContent();
    }


    /*To Get Tooltip Text */
    public String getTooltipText(WebElement element) {
        String tooltipText = element.getAttribute("title").trim();
        return tooltipText;
    }


    /*To Close all Tabs/Windows except the First Tab */
    public void closeAllTabsExceptFirst() {
        ArrayList<String> tabs = new ArrayList<String>(getWebDriver().getWindowHandles());
        for (int i = 1; i < tabs.size(); i++) {
            getWebDriver().switchTo().window(tabs.get(i));
            getWebDriver().close();
        }
        getWebDriver().switchTo().window(tabs.get(0));
    }


    /*To Print all the Windows */
    public void printAllTheWindows() {
        ArrayList<String> al = new ArrayList<String>(getWebDriver().getWindowHandles());
        for (String window : al) {
            System.out.println(window);
        }
    }

}
