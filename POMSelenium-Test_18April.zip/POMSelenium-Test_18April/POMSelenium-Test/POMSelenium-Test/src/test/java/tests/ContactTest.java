package tests;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.controllers.TestDataProviders;

import pageObjects.initializePageObjects.PageFactoryInitializer;

public class ContactTest extends PageFactoryInitializer {
	
	@Test(dataProvider="customer1",dataProviderClass=TestDataProviders.class , priority=1,groups={"Required"})
	public void verifyAddNewContactTest(String firstname,String lastname) throws InterruptedException {
		
		loginpage().verifyLogin("poojabatale09@gmail.com", "Welcome@2021");
		Thread.sleep(5000);
		ContactPage().clickContactLink();
		Thread.sleep(5000);
		ContactPage().movetoelement();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		boolean bln = ContactPage().verifySortContact();
		Assert.assertTrue(bln, "failed");
		ContactPage().createContact(firstname,lastname);
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(5000);
		ContactPage().clickContactLink();
		ContactPage().movetoelement();
		Thread.sleep(5000);
		ContactPage().deleteContact(firstname);
	
		
	}


}
