package pageObjects.Modules;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;
import com.qa.utils.ExplicitWaiting;

public class LoginPageObjects extends BrowserFactory {

 
	
	@FindBy(xpath="//input[@name='email']") 
	   private WebElement email;
	
	@FindBy(xpath="//input[@name='password']") 
	   private WebElement pwd;
	 
	@FindBy(xpath="//*[text()='Login']") 
	   private WebElement btnLogin;
	
	@FindBy(xpath="//a[contains(text(),'Free account')]")
	private WebElement title;
	
	@FindBy(xpath="//div[contains(text(),'Something went wrong...')]")
	private WebElement error1;
	
	@FindBy(xpath="//p[contains(text(),'Invalid login')]")
	private WebElement error2;
	
	@FindBy(xpath="//p[contains(text(),'Invalid request')]")
	private WebElement error3;
	
	@FindBy(xpath="//a[contains(text(),'Forgot your password?')]")
	private WebElement forgotpasslink;
	
	@FindBy(xpath="//h2[contains(text(),'Forgot my password')]")
	private WebElement header;
	
	@FindBy(xpath="//div[contains(text(),'Enter the email you used to register your account.')]")
	private WebElement subheader;
	
	@FindBy(xpath="//button[@name='action']")
	private WebElement resetpassbutton;
	
	

	public WebElement getEmail() {
		return email;
	}


	public void setEmail(WebElement email) {
		this.email = email;
	}


	public WebElement getPwd() {
		return this.pwd;
	}
	
	
	public WebElement getBtnLogin() {
		return this.btnLogin;
	}
	
	public WebElement getTitle() {
		return this.title;
	}
	
	public WebElement getError1() {
		return this.error1;
	}
	public WebElement getError2() {
		return this.error2;
	}
	
	public WebElement getError3() {
		return this.error3;
	}
	
	public WebElement getForgotpasslink() {
		return forgotpasslink;
	}
	public WebElement getHeader() {
		return header;
	}
	public WebElement getsubheader() {
		return subheader;
	}
 
	public WebElement getresetpassbutton() {
		return resetpassbutton;
	}
	


//actions
	public void verifyLogin(String username, String password) throws InterruptedException {
		
		
		
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		getEmail().sendKeys(username);
		//logger.log(Status.PASS, "username is entered");
		
		Thread.sleep(3000);
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		getPwd().sendKeys(password);
		//logger.log(Status.PASS, "Password is entered");
		
		getBtnLogin().click();
		//logger.log(Status.PASS, "Login button is clicked");
		
		
		
		}
	
	   public boolean verifyheaderdisplayed() {		
		return getTitle().isDisplayed();
	   }
	
	//actions
		public void verifyBlank(String expectederrormesg) {
			getEmail().sendKeys("");
			getPwd().sendKeys("");
			getBtnLogin().click();
			
			}
		
		public boolean verifyerror1displayed() {
			
			return getError1().isDisplayed();
		}
		
     public boolean verifyerror2displayed() {
			
			return getError2().isDisplayed();
		}
		
     public boolean verifyError3Displayed() {
    	 return getError3().isDisplayed();
     }
	
     public void clickforgotpasslink() {
    	 BaseMethod.click(forgotpasslink);
     }

}
