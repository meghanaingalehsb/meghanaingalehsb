package tests;

import org.netbeans.lib.cvsclient.util.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.base.Verify;
import com.qa.controllers.TestDataProviders;

import pageObjects.initializePageObjects.PageFactoryInitializer;

public class ValidateLoginTest extends PageFactoryInitializer {
	
	@Parameters({"Name"})
	@Test(dataProvider="loginTestData",dataProviderClass=TestDataProviders.class , priority=1)	
	public void verifyLoginTest(String email,String pass) throws InterruptedException {
		Thread.sleep(9000);
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(OUTPUT_FOLDER + FILE_NAME);
		ExtentReports extend = new ExtentReports();
		extend.attachReporter(sparkReporter);	

		
		ExtentTest logger= extend.createTest("verify login with valid login test data");
		
		loginpage().verifyLogin(email, pass);
		logger.info("login details entered");
		boolean bln = loginpage().verifyheaderdisplayed();
		Assert.assertTrue(bln, "failed");
		
		extend.flush();
		
	}
	
	/*
	  @Test(dataProvider="loginInvalidTestData",dataProviderClass=TestDataProviders.class , priority=2) 
	  public void verifyInvalidLoginTest(String email,String pass) throws InterruptedException {	  
	  loginpage().verifyLogin(email, pass); 
	  boolean error1 = loginpage().verifyerror1displayed(); 
	  boolean error2 = loginpage().verifyerror2displayed(); 
	  Assert.assertTrue(error1,"failed");
	  Assert.assertTrue(error2,"failed"); 
	  }
	 
	  @Test(dataProvider="loginBlankTestData",dataProviderClass=TestDataProviders.class , priority=3) 
	  public void verifyBlankLoginTest(String email,String pass) throws InterruptedException {
		  loginpage().verifyLogin(email, pass);
		  boolean error1 = loginpage().verifyerror1displayed(); 
		  boolean error3 = loginpage().verifyError3Displayed();
		  Assert.assertEquals(error1, true,"failed");
		  Assert.assertEquals(error3, true,"failed");
		  
	  }
	  
	  @Test(groups={"Required","sanity"},priority=4)
	  public void verifyForgotPassTest() {
		  loginpage().clickforgotpasslink();
		  boolean header = loginpage().getHeader().isDisplayed();
		  boolean subheader = loginpage().getsubheader().isDisplayed();
		  boolean forgotpassbtn = loginpage().getresetpassbutton().isDisplayed();
		  Assert.assertEquals(header, true,"failed");
		  Assert.assertEquals(subheader, true,"failed");
		  Assert.assertEquals(forgotpassbtn, true,"failed"); 
		  
		  
		
	  } */

}
