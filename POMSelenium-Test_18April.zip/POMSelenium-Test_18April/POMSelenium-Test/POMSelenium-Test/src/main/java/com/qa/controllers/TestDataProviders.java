package com.qa.controllers;

import java.io.IOException;

import org.testng.annotations.DataProvider;

import com.qa.utils.ExcelUtils;


public class TestDataProviders {
	
	
	@DataProvider(name="loginTestData")
	public static Object[] loginTestData()
	{
		return new Object[][]
				{
			         {"meghana_ingale@hsb.com"}
			         
				};
	}
	
	@DataProvider(name="loginInvalidTestData")
	public static Object[][] loginInvalidTestData()
	{
		return new Object[][]
				{
			         {"ajitbhosale@gmail.com","Welcome"}						
						  
						 
				};
	}
	
	@DataProvider(name="loginBlankTestData")
	public static Object[][] loginBlankTestData()
	{
		return new Object[][]
				{
			         {"",""}						
						  
						 
				};
	}
	
	@DataProvider(name="customer1")
	public static Object[][] customer1()
	{
		return new Object[][]
				{
			         {"Manju","Pola"}
				};
	}
	
	
	
	@DataProvider(name="getexcelTestData")
	public Object[][] getexcelTestData() throws IOException{
		
		Object data[][] = ExcelUtils.getTestData("Singinup");
		return data;
	}
	
	@DataProvider(name="addDealTestData")
	public static Object[][] addDealTestData()
	{
		return new Object[][]
				{
			         {"Deal123","30/01/2022 01:15","New deal has been created","Negotiate"}
				};
	}
	
		
	
}
