package com.qa.utils;

import org.openqa.selenium.WebElement;

public class Verification {
	
	/*Summary :This function is created by Meghana Ingale on 17-04-23 and It is created for verify page*/
	 public void verify_page(WebElement webelement, String strtext)
	 {
		 if(webelement.isDisplayed())
		 {
			 System.out.println("Landed successfully  on " +strtext);
			 
		 }
		 else
		 {
			 System.out.println("not Landed on " +strtext);
		 }
	 }

	 
	 /*Summary :This function is created by Meghana Ingale on 17-04-23 and It is created for verify images*/
	 public void verify_image(WebElement webelement, String strtext)
	 {
		 if(webelement.isDisplayed())
		 {
			 System.out.println(strtext+ "displayed successfully");
			 
		 }
		 else
		 {
			 System.out.println(strtext+ " not displayed ");
		 }
	 }

	 /*Summary :This function is created by Meghana Ingale on 17-04-23 and It is created for verify text*/
	 public void verify_text(WebElement webelement, String strtext)
	 {
		 if(webelement.isDisplayed())
		 {
			 System.out.println(strtext+ "displayed successfully");
			 
		 }
		 else
		 {
			 System.out.println(strtext+ " not displayed ");
		 }
	 }

}
