package pageObjects.Modules;

import java.awt.List;
import java.time.Duration;
import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;
import com.qa.utils.ExplicitWaiting;

public class SignINUPPageObjects extends BrowserFactory {
/*Zeguro folder xpath*/
	
	@FindBy(xpath="//span[text()='Zeguro']")
    private WebElement Zeguro_folder;

	public WebElement getZeguro_folder() {
		return Zeguro_folder;
	}

	public void setZeguro_folder(WebElement zeguro_folder) {
		Zeguro_folder = zeguro_folder;
	}
	 /*xpath for mail subject*/
	@FindBy(xpath="//span[text()='Complete your Cyber Safety sign up']")
	private WebElement mailsubject;
	
	public WebElement getVerify_mail() {
		return verify_mail;
	}

	public void setVerify_mail(WebElement verify_mail) {
		this.verify_mail = verify_mail;
	}
	@FindBy(xpath="//a[text()='Verify Email ']")
	private WebElement verify_mail;
	
    public WebElement getMailsubject() {
		return mailsubject;
	}

	public void setMailsubject(WebElement mailsubject) {
		this.mailsubject = mailsubject;
	}

	//actions
	/*click on Zeguro folder*/
	public void ZeguroFolder_click()
	{
	BaseMethod.mouseHoverAndClick(Zeguro_folder);
  
	}
	public void MailSubject_click()
	{
	BaseMethod.mouseHoverAndClick(mailsubject);
  
	}
	public void Verify_mail_click()
	{
	BaseMethod.mouseHoverAndClick(verify_mail);
  
	}
}
