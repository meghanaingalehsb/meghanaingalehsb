package pageObjects.initializePageObjects;

import org.openqa.selenium.support.PageFactory;

import com.qa.controllers.BaseMethod;

import pageObjects.Modules.CalendarPageObjects;
import pageObjects.Modules.ContactPageObjects;
import pageObjects.Modules.DealsPageObjects;
import pageObjects.Modules.LoginPageObjects;
import pageObjects.Modules.HandlingWindowURL;
import pageObjects.Modules.SignUp_01_PageObject;
import pageObjects.Modules.SignINUPPageObjects;



public class PageFactoryInitializer extends BaseMethod {
	
	 public LoginPageObjects loginpage() {
	        return PageFactory.initElements(getWebDriver(), LoginPageObjects.class);
	    }
	 
	 //ContactPageObjects
	 
	 public ContactPageObjects ContactPage() {
	        return PageFactory.initElements(getWebDriver(), ContactPageObjects.class);
	    }

	 //dealspage
	 public DealsPageObjects DealsPage() {
		 return PageFactory.initElements(getWebDriver(), DealsPageObjects.class);
	 }
	 
	//Calendar page
		 public CalendarPageObjects CalendarPage() {
			 return PageFactory.initElements(getWebDriver(), CalendarPageObjects.class);
		 }
		 
     //Handlingwindowurl
		 public HandlingWindowURL SigninPage() {
		        return PageFactory.initElements(getWebDriver(), HandlingWindowURL.class);
		    }
		 
		 //signup
		 public SignUp_01_PageObject SignupPage() {
		        return PageFactory.initElements(getWebDriver(), SignUp_01_PageObject.class);
		    }
		 //signinup
		 public SignINUPPageObjects EmailPage()
		 {
			return PageFactory.initElements(getWebDriver(), SignINUPPageObjects.class);
		 }
		 
}
