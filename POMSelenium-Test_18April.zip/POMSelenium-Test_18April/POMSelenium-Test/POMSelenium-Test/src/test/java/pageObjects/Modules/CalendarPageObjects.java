package pageObjects.Modules;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;

public class CalendarPageObjects extends BrowserFactory {
	
	@FindBy(xpath="//span[contains(text(),'Calendar')]")
	private WebElement calendarlink;

	public WebElement getCalendarlink() {
		return calendarlink;
	}
	
	//button[contains(text(),'Create')]
	
	@FindBy(xpath="//button[contains(text(),'Create')]")
	private WebElement createBtn;

	public WebElement getcreateBtn() {
		return createBtn;
	}

	public void createCalendarEvent(){
		
		BaseMethod.mouseHoverAndClick(calendarlink);	
	
		BaseMethod.mouseHover(createBtn);
			
		
	}
}
