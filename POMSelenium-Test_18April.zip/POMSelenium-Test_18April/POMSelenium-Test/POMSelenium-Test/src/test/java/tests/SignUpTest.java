package tests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.awt.List;
import java.util.Set;

import org.netbeans.lib.cvsclient.util.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.base.Verify;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.TestDataProviders;
import com.qa.controllers.WebDriverFactory;
import LibraryFuctions.SignInUpfunctions;
import pageObjects.Modules.SignUp_01_PageObject;
import pageObjects.initializePageObjects.PageFactoryInitializer;

public class SignUpTest extends PageFactoryInitializer {
	
	
	SignInUpfunctions fn=new SignInUpfunctions();
    SignUp_01_PageObject sn=new SignUp_01_PageObject();
    
    
   //test for signup through direct channel
	@Test(dataProvider="getexcelTestData",dataProviderClass=TestDataProviders.class,priority=2)	
	public void SignUpThroughdirectchannel(String emailid,String password,String companyname, String web, String fname ,String lname, String iuser) throws InterruptedException {
		
		Thread.sleep(9000);
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(OUTPUT_FOLDER + FILE_NAME);
		ExtentReports extend = new ExtentReports();
		extend.attachReporter(sparkReporter);
		Thread.sleep(3000);
		//handle munichre login window
		
		 SigninPage().enteremail(emailid);
	
	     Thread.sleep(3000);
         SigninPage().clickonnext();
         Thread.sleep(3000);
         SigninPage().click_on_Agree();
         Thread.sleep(3000);
    		
		//click on signup button

		SignupPage().click_on_sugnup();
		//enter mail id
		Thread.sleep(3000);
		SignupPage().verify_cyber_safety_logo();
		Thread.sleep(3000);
		SignupPage().enteremailid(emailid);
		Thread.sleep(3000);
		//enter password
		Thread.sleep(3000);
		SignupPage().enterpassword(password);
		//click on signup
		Thread.sleep(3000);
		SignupPage().click_onStartFreeTrail();
		Thread.sleep(30000);
		//go to email and click 'Verify email'
		//setWebDriver(driver);
	     fn.Emailverification("Complete your Cyber Safety sign up");
	     Thread.sleep(10000);
	  
	     
	     //Get the current window handle
	       String currentWindowHandle = driver.getWindowHandle();

	       // Get all window handles
	       Set<String> allWindowHandles = driver.getWindowHandles();

	       // Loop through the window handles and switch to the new window
	       for (String windowHandle : allWindowHandles) 
	       {
	           if (!windowHandle.equals(currentWindowHandle))
	           {
	        	
	       driver.switchTo().window(windowHandle);
	       //handle sign-in page
	       try
	       {
	    	   
	       if(driver.findElement(By.xpath("//button[@id='sign-in-button']")).isDisplayed())
	       {
	    	   Thread.sleep(3000);
	  
	    	   fn.SignIn(emailid, password);
	    	   Thread.sleep(4000);
	  	     SignupPage().verify_cyber_safety_page();
	  	   
	       }
	       }
	       catch(NoSuchElementException e)
        	{
        		System.out.println(e.getMessage());
        	}
	      
	       break;
	        
	           }
    	 }
  
    //verify profile icon with email in the upper right corner
	     Thread.sleep(3000);
	     SignupPage().verify_profile_logo();
	    
	     Thread.sleep(3000);
	     SignupPage().verify_emailid_text();
	     
	     Thread.sleep(3000);
	     
	     for (String windowHandle : allWindowHandles) 
	       {
	           if (!windowHandle.equals(currentWindowHandle))
	           {
	        	  
	            driver.switchTo().window(windowHandle);
	            Thread.sleep(3000);
	            
	          //land on Welcome to Cyber Safety page
	            SignupPage().verify_cyber_safety_page();
	     //click 'Continue'
	     Thread.sleep(3000);
	     SignupPage().click_on_onboarding_button();
	    break;
	           }
	       }
	     //fill out 4 fields, click Next
	     for (String windowHandle : allWindowHandles) 
	       {
	           if (!windowHandle.equals(currentWindowHandle))
	           {
	        	  
	     Thread.sleep(4000);
	     SignupPage().enter_company_name(companyname);
	     Thread.sleep(3000);
	     SignupPage().click_on_primaryindustry();
	     SignupPage().click_on_education();
	     Thread.sleep(3000);
	     SignupPage().click_on_teammember();
	     SignupPage().click_on_teamsize();
	     Thread.sleep(300);
	     SignupPage().enter_primary_webaddress(web);
	     Thread.sleep(3000);
	     SignupPage().click_on_next1();
	     break;
	           }
	       }
	     
	     //fill out 3 fields, click Next
	    
   	   Thread.sleep(3000);
   	   SignupPage().enter_first_name(fname);
   	   SignupPage().enter_last_name(lname);
   	   SignupPage().click_on_next1();
	        	   
   	   Thread.sleep(3000);
       SignupPage().enter_invited_user(iuser);
       SignupPage().click_on_done();
	        	  
	        	  
	   
	   //verify toast message 'Invited user successfully'    
	     Thread.sleep(3000);
	     SignupPage().verify_invited_user_toast_message();
	     
	  //verify 'Welcome to Cyber Safety' modal (should contain 'training', 'scan', 'security policies' wording 
	     Thread.sleep(3000);
	     SignupPage().verify_welcome_cybersafety_module();
	     SignupPage().verify_contractual_text();
	     SignupPage().verify_scan_websites();
	   //click 'Got it'
	     SignupPage().click_on_gotit();
	  //verify the presence of 4 cards on Dashboard (Security Policies, Training, Monitoring, Marketplace)
	     SignupPage().verify_monitoring_card();
	     SignupPage().verify_security_card();
	     SignupPage().verify_training_card();
	     SignupPage().verify_marketplace_card();
	     
	  //verify 9 items in the navigation bar (Dashboard, Sec Pol, Tr, Mon, Ins, Mark, Sett, My Plan, Sup)
	     SignupPage().verify_dashboard();
	     SignupPage().verify_Security_policies();
	     SignupPage().verify_training();
	     SignupPage().verify_monitoring();
	     SignupPage().verify_insurance();
	     SignupPage().click_on_profileicon();
	     SignupPage().verify_setting();
	     SignupPage().verify_support();
	     SignupPage().verify_myplan();
	     SignupPage().verify_cyber_safety_ondashboard();
	     SignupPage().click_on_setting();
	}
	
}
