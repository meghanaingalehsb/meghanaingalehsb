package com.qa.controllers;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserFactory extends InitMethod {
	
	public static WebDriver driver;

    static WebDriver createDriver() {
    	
        switch (Browser.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                
                //ChromeOptions option = new ChromeOptions();
                //option.setExperimentalOption("debuggerAddress", "localhost:8989");
                //driver = new ChromeDriver(option);
                
                
                //to open browser in incognito Mode
                
				/*
				 * ChromeOptions option = new ChromeOptions();
				 * option.addArguments("--incognito");
				 * 
				 * DesiredCapabilities cap = new DesiredCapabilities();
				 * cap.setCapability(ChromeOptions.CAPABILITY, option); option.merge(cap);
				 * driver = new ChromeDriver(option);
				 */
                
                
                break;


            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                //FirefoxOptions firefoxOptions = new FirefoxOptions();
                //firefoxOptions.addArguments("--headless");
                //driver = new FirefoxDriver(firefoxOptions);
                driver = new FirefoxDriver();
                break;

            case "ie":
            case "internet explorer":
                WebDriverManager.iedriver().setup();
                driver = new InternetExplorerDriver();
                break;

            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;


            default:
                throw new NotFoundException("Browser Not Found. Please Provide a Valid Browser in the List");
        }

        if (ImplicitlyWait > 0) {
            implicitlyWait(ImplicitlyWait);
        }

        if (MaxPageLoadTime > 0) {
            setMaxPageLoadTime(MaxPageLoadTime);
        }

        driver.manage().window().maximize();
        driver.get(WebsiteURL);
      
    
   
        //driver.manage().deleteAllCookies();
        return driver;
        
       
    }
  
    public static void implicitlyWait(long timeInSeconds) {
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    }

    public static void setMaxPageLoadTime(long timeInSeconds) {
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
    }

}
