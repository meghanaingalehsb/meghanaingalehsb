package pageObjects.Modules;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;
import com.qa.utils.ExplicitWaiting;

public class HandlingWindowURL extends BrowserFactory {
	
	//xpath
	/*xpath for handling munichre website*/
	
	@FindBy(xpath="//input[@type='email']") 
	   private WebElement email;
  /*xpath for next button  */ 
	@FindBy(xpath="//input[@type='submit']") 
	 private WebElement next;
	/*xpath for the Agree button*/
	@FindBy(xpath="//a[@id='hs-eu-confirmation-button']")
	private WebElement Agreebutton;
	
  
	public WebElement getAgreebutton() {
		return Agreebutton;
	}

	public void setAgreebutton(WebElement agreebutton) {
		Agreebutton = agreebutton;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getNext() {
		return next;
	}

	public void setNext(WebElement next) {
		this.next = next;
	}

	//action
	
	
	public void enteremail(String emailid) {
		email.sendKeys(emailid);
		
		}
	/*click on next button*/
	public void clickonnext() {
		BaseMethod.mouseHoverAndClick(next);
			
	}
	/*click on the Agree button*/
	public void click_on_Agree()
	{
		
	//driver.switchTo().frame(1);
	BaseMethod.mouseHoverAndClick(Agreebutton);;
	}
	
}
