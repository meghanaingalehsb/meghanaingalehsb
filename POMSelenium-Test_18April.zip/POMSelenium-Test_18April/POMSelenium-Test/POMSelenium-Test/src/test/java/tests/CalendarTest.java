package tests;

import org.testng.annotations.Test;

import pageObjects.initializePageObjects.PageFactoryInitializer;

public class CalendarTest extends PageFactoryInitializer {
	@Test(priority=1)
	public void verifyAddNewCalenderEvent() throws InterruptedException {
		
		loginpage().verifyLogin("poojabatale09@gmail.com", "Welcome@2021");
		Thread.sleep(5000);
		
		CalendarPage().createCalendarEvent();
		
		
	}

}
