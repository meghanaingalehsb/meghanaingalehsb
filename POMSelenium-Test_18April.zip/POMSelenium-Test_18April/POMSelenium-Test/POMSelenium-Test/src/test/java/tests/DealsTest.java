package tests;

import org.testng.annotations.Test;

import com.qa.controllers.TestDataProviders;

import pageObjects.initializePageObjects.PageFactoryInitializer;

public class DealsTest extends PageFactoryInitializer {
	@Test(priority=1,dataProvider="addDealTestData",dataProviderClass=TestDataProviders.class,groups = {"Required"})
	public void VerifyAddNewDealTest(String strtitle,String strdate,String strdescription,String strselectstagevalue) throws InterruptedException {
		
		loginpage().verifyLogin("poojabatale09@gmail.com", "Welcome@2021");
		Thread.sleep(5000);
		DealsPage().clickDealLink();
		Thread.sleep(5000);
		DealsPage().addNewDeal(strtitle,strdate,strdescription,strselectstagevalue);
		
	}

}
