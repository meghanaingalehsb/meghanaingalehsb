package LibraryFuctions;
import org.testng.Assert;
import org.testng.annotations.Test;

import org.netbeans.lib.cvsclient.util.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.base.Verify;
import com.qa.controllers.BaseMethod;
import com.qa.controllers.TestDataProviders;
import com.qa.controllers.WebDriverFactory;

import pageObjects.initializePageObjects.PageFactoryInitializer;

public class SignInUpfunctions extends PageFactoryInitializer {
	
	/*Summary :-This function is added by Meghana Ingale on 17-04-23 
    * It created for verify email  link by using web outlook app and click on verify link*/
    
		
	public void Emailverification(String inputmessage) throws InterruptedException {
		 
	 driver.get("https://outlook.office365.com/mail/");
      BaseMethod.implicitlyWait(10000);
      Thread.sleep(5000);
     EmailPage().ZeguroFolder_click();
     
     //driver.switchTo().alert().accept();
     Thread.sleep(5000);
     java.util.List<WebElement> emailsubject=driver.findElements(By.xpath("//span[text()='Complete your Cyber Safety sign up']"));
     if(emailsubject.size()>0)
     {
     for(WebElement element:emailsubject)
     {
   	
    	if(element.getText().contentEquals("Complete your Cyber Safety sign up"))
   	        {
   	      Thread.sleep(5000);
   		
   		System.out.println("Email Received" +element.getText());
   		Thread.sleep(5000);
   	    EmailPage().getMailsubject();
   	    EmailPage().MailSubject_click();
   	    Thread.sleep(5000);
   	    EmailPage().Verify_mail_click();
   		break;
   	         }
         }
       }
	}
   
	/*Summary :-This function is added by Meghana Ingale on 17-04-23 
	 *  It created for Signin*/
	
	public void SignIn(String email,String password)
	{
	 SignupPage().enter_sigin_id(email);
	 SignupPage().enter_sigin_pass(password);
	 SignupPage().click_signin_button();
	}
	
	
	
	/*Summary :-This function is added by Meghana Ingale on 17-04-23
	 * It created for signup*/
	
	public void SignUp(String email,String password)
	{
		SignupPage().enteremailid(email);
		SignupPage().enterpassword(password);
		
	}
}
