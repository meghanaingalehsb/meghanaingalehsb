package pageObjects.Modules;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;
import com.qa.controllers.WebDriverFactory;

public class ContactPageObjects extends BrowserFactory{
	
	//body/div[@id='ui']/div[1]/div[1]/div[3]/a[1]/i[1]
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[1]/div[3]/a[1]/i[1]")
	WebElement contactlink;
	
	@FindBy(xpath="//button[text()='Show Filters']")
	WebElement btnshowfilter;
		
	@FindBy(xpath="//button[text()='Create']")
	WebElement btnCreate;
	
	//first_name
	@FindBy(name="first_name")
	WebElement firstname;
	
	//lastname
	@FindBy(name="last_name")
	WebElement lastname;
		
	@FindBy(xpath="//button[text()='Save']")
	WebElement btnSave;
	
	@FindBy(xpath="//div[@class='ui header item mb5 light-black']")
	WebElement actualcontactname;
	
	@FindBy(xpath="//button[text()='Delete']")
	WebElement btnDelete;
	
	@FindBy(xpath="//th[contains(text(),'Name')]")
	WebElement columnname;
	
	
	
	//actions
	
	public void clickContactLink() {
		BaseMethod.mouseHoverAndClick(contactlink);
		
	}
	
	public void movetoelement() {
		BaseMethod.mouseHover(btnCreate);
		
	}
	
	public void createContact(String strfirstname,String strlastname) {
		//btnCreate.click();
		BaseMethod.click(btnCreate);
		BaseMethod.sendKeys(firstname,strfirstname);
		BaseMethod.sendKeys(lastname,strlastname);
		BaseMethod.click(btnSave);
		
		
	}
	
	public boolean verifySortContact() throws InterruptedException {
		
	
	 List<WebElement> list =driver.findElements(By.xpath("//tbody/tr"));
	 List<String> beforesort = new ArrayList<>();
	 List<String> aftersort = new ArrayList<>();
	 String strname;
	 
	 for (int i = 1; i <= list.size(); i++) {
		 
		 strname = driver.findElement(By.xpath("//tbody/tr["+i+"]/td[2]/a")).getText();
		 beforesort.add(strname);
		
	}
	Collections.sort(beforesort,Collections.reverseOrder());
	 BaseMethod.click(columnname);
	 Thread.sleep(5000);
		
	 for (int i = 1; i <= list.size(); i++) {
		
		 strname = driver.findElement(By.xpath("//tbody/tr["+i+"]/td[2]/a")).getText();
		 aftersort.add(strname);
		
	}
	 boolean bool = beforesort.equals(aftersort); 
	 return bool;
		
	}
	
	
	public void deleteContact(String name) {
		 List<WebElement> list =driver.findElements(By.xpath("//tbody/tr"));
		 String strname;
		 for (int i = 1; i <= list.size(); i++) {
			 
			 strname = driver.findElement(By.xpath("//tbody/tr["+i+"]/td[2]/a")).getText();
			if(strname.contains("Manju")){
				driver.findElement(By.xpath("//tbody/tr["+i+"]/td[8]/div[1]/button[1]")).click();
				driver.findElement(By.xpath("//body/div[3]/div[1]/div[3]/button[2]/i[1]")).click();
				break;
			}
			
		}
		
	}

}
