package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import org.netbeans.lib.cvsclient.util.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.base.Verify;
import com.qa.controllers.TestDataProviders;


import pageObjects.initializePageObjects.PageFactoryInitializer;
/*this function is created by Meghana on 14-04-23.It will handle munichre window url*/
public class HandlingWindowURL extends PageFactoryInitializer {
	
	@Test(dataProvider="loginTestData",dataProviderClass=TestDataProviders.class,priority=1)	
	public void HandlingWindowURL(String email) throws InterruptedException {
		Thread.sleep(9000);
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(OUTPUT_FOLDER + FILE_NAME);
		ExtentReports extend = new ExtentReports();
		extend.attachReporter(sparkReporter);
		Thread.sleep(3000);
		SigninPage().enteremail(email);
	
		Thread.sleep(3000);
       SigninPage().clickonnext();
       Thread.sleep(3000);
       SigninPage().click_on_Agree();
      
		
		ExtentTest logger= extend.createTest("verify login with valid login test data");
		extend.flush();
	
	
	}
}
