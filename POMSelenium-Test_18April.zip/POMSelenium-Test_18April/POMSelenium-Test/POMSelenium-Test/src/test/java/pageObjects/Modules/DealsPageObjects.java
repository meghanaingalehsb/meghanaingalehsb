package pageObjects.Modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.controllers.BaseMethod;
import com.qa.controllers.BrowserFactory;

public class DealsPageObjects extends BrowserFactory  {
	
	@FindBy(xpath="//input[@name='title']")
	WebElement title;
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[2]/div[2]/div[1]/div[2]/form[1]/div[4]/div[1]/div[1]/div[1]/div[1]/input[1]")
	WebElement closedate; 
	//30/01/2022 01:15
	
	
	@FindBy(xpath="//textarea[@name='description']")
	WebElement description;	
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[1]/div[5]/a[1]/i[1]")
	WebElement deallink;
	
	
	@FindBy(xpath="//button[contains(text(),'Pipeline')]")
	WebElement btnpipeline;	
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/a[3]/button[1]")
	WebElement btnCreate;	
	
	@FindBy(xpath="//input[@name='amount']")
	WebElement amount;
	
	//
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[2]/div[2]/div[1]/div[2]/form[1]/div[7]/div[1]/div[1]/div[1]")
	WebElement drpstage;
	
	@FindBy(xpath="//body/div[@id='ui']/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/button[2]")
	WebElement btnSave;
	
	//actions
	
	public void clickDealLink() {
		BaseMethod.mouseHoverAndClick(deallink);
		
	}
	
	public void movetoelement() {
		BaseMethod.mouseHover(btnpipeline);
		
	}
	
	public void addNewDeal(String strtitle,String strdate,String strdescription,String strselectstagevalue) {
		
		BaseMethod.click(btnCreate);
		title.sendKeys(strtitle);
		closedate.sendKeys(strdate);
		description.click();
		description.sendKeys(strdescription);
		amount.sendKeys("45");
		selectStage(strselectstagevalue);
		btnSave.click();
		
		
	}
	
	public void selectStage(String strselectstagevalue) {
		drpstage.click();				
		List<WebElement> li =driver.findElements(By.xpath("//div[@name='stage']/span"));			
		for (int i = 1; i <=li.size(); i++) {			
			String name=li.get(i).getText();
			
			if (name.equalsIgnoreCase(strselectstagevalue)) {
				li.get(i).click();
				break;
			}
		}
	}
	

}
