package com.qa.controllers;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import ru.qatools.properties.Property;
import ru.qatools.properties.PropertyLoader;
import ru.qatools.properties.Resource;


public class ApplicationConfigReader {
	public static Properties prop;
	
	public ApplicationConfigReader() {
		prop = new Properties();
		FileInputStream ip = null;
		try {
			ip = new FileInputStream("C:\\Users\\ny210323\\Downloads\\POMSelenium-Test\\POMSelenium-Test\\src\\main\\resources\\ApplicationConfig.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			prop.load(ip);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	/*
	 * @Property(value = "Browser") private String Browser;
	 * 
	 * @Property(value = "Url") private String WebsiteUrl;
	 * 
	 * @Property(value = "MaxPageLoadTime") private int MaxPageLoadTime;
	 * 
	 * @Property(value = "ImplicitlyWait") private int ImplicitlyWait;
	 * 
	 * public String getBrowser() { return Browser; }
	 * 
	 * public String getWebsiteUrl() { return WebsiteUrl; }
	 * 
	 * public int getMaxPageLoadTime() { return MaxPageLoadTime; }
	 * 
	 * public int getImplicitlyWait() { return ImplicitlyWait; }
	 */
}

